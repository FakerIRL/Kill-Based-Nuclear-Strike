# Nuke UI — v1.0

**Dev by Fake.dev**

A FiveM resource that adds a nuclear strike event with a military-style HTML UI and a hacking-style finale.

## Features
- **+1 score per kill** (per entity killed)
- At **20 kills**, the nuke becomes **available**
- **F6** opens the tablet, **hold F6 for 3 seconds** to confirm launch
- **5-second countdown** before impact
- Nearby players receive a warning, then a **console/hacking screen**, then explosions

## Controls
- **F6**: Expand tablet / Hold 3s to confirm
- **ESC**: Minimize/close the tablet (shows a small right-side widget). Press **F6** to expand again.

## Version
This is **Version 1 (v1.0)** — updates and improvements are coming soon.
